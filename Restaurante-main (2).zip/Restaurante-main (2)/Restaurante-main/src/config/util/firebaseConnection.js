import { initializeApp, getApp } from "firebase/app";
import { initializeAuth, getAuth, getReactNativePersistence } from 'firebase/auth';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';
import { getFirestore } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyDsYc1JveoHl05t32FBToYEtvvEyJsvtCg",
  authDomain: "restauranteb-3389f.firebaseapp.com",
  projectId: "restauranteb-3389f",
  storageBucket: "restauranteb-3389f.appspot.com",
  messagingSenderId: "619135088895",
  appId: "1:619135088895:web:fe3b004120bf4059ca34ca"
};

const app = initializeApp(firebaseConfig);
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});
const db =getFirestore (app)

export  {app, auth};