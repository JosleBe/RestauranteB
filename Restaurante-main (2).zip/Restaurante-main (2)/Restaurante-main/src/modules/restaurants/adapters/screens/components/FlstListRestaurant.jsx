import React from 'react'
import { StyleSheet, View, Text } from 'react-native';
import { AirbnbRating, Image } from "@rneui/base";
export default  function FlstListRestaurant (props) {
    const {image, title, description, rating} = props;
    return (
        <View style={styles.listRestaurant}>
            <Image source={{ uri: `${image}` }}
                style={styles.image} />
            <View style={styles.containerText}>
                <View style={{ flexDirection: 'row', justifyContent:'space-between' }}>
                    <Text style={styles.title}>{title}</Text>
                    <AirbnbRating count={5} isDisabled={true} defaultRating={rating} size={12} showRating={false} />
                </View>
                <Text style={styles.description}>{description}</Text>
            </View>
        </View>
    )
}


const styles = StyleSheet.create({
    listRestaurant: {
        flex: 1,
        flexDirection: "row",
        marginBottom: 16,
        elevation:2,
        padding:8
      },
    
      image: {
        width: 124,
        height: 124
      },
      title: {
        fontSize: 16,
        fontWeight: "bold",
        marginRight: 16
      },
      description: {
        fontSize: 12
      },
      containerText: {
        flex: 1,
        flexDirection: 'column',
        padding: 8
    
      }
})
