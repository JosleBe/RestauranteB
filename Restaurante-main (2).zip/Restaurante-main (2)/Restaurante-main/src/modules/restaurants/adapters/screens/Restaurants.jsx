import { StyleSheet, Text, View, FlatList } from "react-native";
import React, { useEffect, useState } from "react";
import { collection, getDocs, getFirestore } from "firebase/firestore";
import { Icon } from "@rneui/base";
import FlstListRestaurant from "./components/FlstListRestaurant";
import Loading from "../../../../kernel/components/Loading"

export default function Restaurants() {
  /*const restaurants = [
    {
      uid: 1,
      title: "Rincon del bife",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Doloremque ipsum impedit expedita deserunt quam. Ab non similique iure, assumenda autem quos commodi ut vel id obcaecati eveniet perspiciatis esse corporis.  ",
      image: "https://via.placehold.it/124x124",
      rating: 4

    },
    {
      uid: 2,
      title: "El boti",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Doloremque ipsum impedit expedita deserunt quam. Ab non similique iure, assumenda autem quos commodi ut vel id obcaecati eveniet perspiciatis esse corporis.  ",
      image: "https://via.placehold.it/124x124",
      rating: 5
    }
  ]
  */
  const db = getFirestore();
  const [restaurants, setRestaurants] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (() => {
      (async () => {
        const querySnapshot = await getDocs(collection(db, "restaurants"));
        const arrayRestaurants = [];
        querySnapshot.forEach((doc) => {
          console.log(`${doc.id} => ${doc.data()["title"]}`);
          arrayRestaurants.push({
            uid: doc.id,
            title: doc.data()["title"],
            description: doc.data()["description"],
            rating: doc.data()["rating"],
            image: doc.data()["image"]
          })
          setRestaurants(arrayRestaurants);
        });
      })
    })();
  }, [])
  return (

    <View style={styles.container}>
      <FlatList
        data={restaurants}
        renderItem={({ item }) =>
          <FlstListRestaurant
            image={restaurants[0].image}
            title={restaurants[0].title}
            description={restaurants[0].description}
            rating={restaurants[0].rating}

          />}
        keyExtractor={item => item.uid}
      />
      <Loading  isShow= {loading} title = {"Cargando restarantes"}/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 16

  },

});
