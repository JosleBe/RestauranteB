import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button} from "react-native";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../../../../../config/util/firebaseConnection";
export default function CreateAccount() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleRegistro = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      console.log("Usuario registrado exitosamente");
    } catch (error) {
      console.error(error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Registro</Text>
      <TextInput
        style={styles.input}
        placeholder="Correo electrónico"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <View style={styles.btnContainer}>
        <Button title="Registrarse" onPress={handleRegistro} color="#ef524a" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  heading: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    width: "80%",
    height: 40,
    marginBottom: 10,
    paddingHorizontal: 16,
  },
  btnContainer: {
    width: "80%",
    marginTop: 20,
  },
});

/**
 * r = react
 * n = native
 * f = function
 * s = style
 * rnfs
 */