import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Profile() {
  const handleLogout = () => {
    firebase.auth().signOut()
      .then(() => {
        // La sesión del usuario ha sido cerrada con éxito.
        console.log('Sesión cerrada');
        // Aquí podrías redirigir a la pantalla de inicio de sesión, por ejemplo.
      })
      .catch((error) => {
        // Ocurrió un error al intentar cerrar la sesión.
        console.error('Error al cerrar la sesión:', error);
      });
  };

  return (
    <View style={styles.container}>
      <Button title="Cerrar sesión" onPress={handleLogout} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});